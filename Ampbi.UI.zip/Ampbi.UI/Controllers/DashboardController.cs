﻿using Ampbi.Business.Business;
using Ampbi.Business.Interface;
using Ampbi.DataAccess.DTOModels;
using Ampbi.DataAccess.ViewModel;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;

namespace Ampbi.UI.Controllers
{
    public class DashboardController : Controller
    {
        #region Private Variables
        private IDashBoard dashDetails;
        private IAccountDetails accDetails;
        private DashBoard dashboard;
        private EmployeePerformanceObjects empPerformObj;
        private EmployeeIndividualPerformanceObjects empIndPerfObj;

        private string iconPath;
        #endregion

        #region defaultpage
        public ActionResult DefaultPage(string id)
        {
            //Checking the modiicon id
            if (Session["LoggedInUserEmail"] ==null)
                return RedirectToAction("Login", "Account");
            dashDetails = new DashboardDetails();
            if (id != null)
                Session["modiicon"] = id;
            if (Session["modiicon"] != null )
            {
                iconPath = GetModiIconPath(Session["modiicon"].ToString());
                dashDetails.InsertMoodiTrans(Session["LoggedInUserEmail"].ToString(), iconPath);

            }
            DashBoard.modiIconPath = iconPath;
          
            return View();
        }

        #endregion

        #region Registration Folloup

        [HttpGet]
        public ActionResult RegAcctFollowUp()
        {


            if (Session["modiicon"] != null)
            {
                iconPath = GetModiIconPath(Session["modiicon"].ToString());
            }
            dashboard = new DashBoard();
            DashBoard.modiIconPath = iconPath;

            dashDetails = new DashboardDetails();
            dashboard.LstNoOfEmpList = dashDetails.GetAllMiscToBind("Signup", "NoofEmployees");
            dashboard.LstNoOfLicencesList = dashDetails.GetAllMiscToBind("Signup", "NoofLicences");
            dashboard.LstNoOfPrefferedContact = dashDetails.GetAllMiscToBind("Signup", "PrefferedContactMethod");

            dashboard.LstNoOfRecStatusList = dashDetails.GetAllMiscToBind("Signup", "RecStatus");

            dashboard.lstAllStateNames = dashDetails.GetAllStateNamesList();
            dashboard.userRegModel = dashDetails.getRegisteredUserDetails();

            return View("RegAcctFollowUp", dashboard);
        }
        [HttpPost]
        public ActionResult RegAcctFollowUp(DataAccess.DTOModels.RegistrationFollowUpUpdateModel model)
        {

            dashboard = new DashBoard();
            dashDetails = new DashboardDetails();

            if (Session["modiicon"] != null)
            {
                iconPath = GetModiIconPath(Session["modiicon"].ToString());
            }
            DashBoard.modiIconPath = iconPath;
            //board.companyRegModel = dashDetails.getRegisteredUserDetails(DashBoard.UsrSeqID);

            if (!string.IsNullOrEmpty(model.CompanyGUID))
            {
                bool result = dashDetails.insertRegistrationFolloup(model, HttpContext.User.Identity.Name);
                if (result)
                    return Json(result);
                else
                    return Json(false);
            }
            dashboard.LstNoOfEmpList = dashDetails.GetAllMiscToBind("Signup", "NoofEmployees");
            dashboard.LstNoOfLicencesList = dashDetails.GetAllMiscToBind("Signup", "NoofLicences");
            dashboard.LstNoOfRecStatusList = dashDetails.GetAllMiscToBind("Signup", "RecStatus");
            dashboard.LstNoOfPrefferedContact = dashDetails.GetAllMiscToBind("Signup", "PrefferedContactMethod");
            dashboard.lstAllStateNames = dashDetails.GetAllStateNamesList();
            dashboard.userRegModel = dashDetails.getRegisteredUserDetails();
            return View(dashboard);
        }

        [HttpGet]
        public ActionResult GetCompanyDetails(string selectedValue)
        {
            if (ModelState.IsValid)
            {

            }
            dashboard = new DashBoard();
            dashDetails = new DashboardDetails();

            dashboard.lstAllStateNames = dashDetails.GetAllStateNamesList();
            dashboard.LstNoOfEmpList = dashDetails.GetAllMiscToBind("Signup", "NoofEmployees");
            dashboard.LstNoOfLicencesList = dashDetails.GetAllMiscToBind("Signup", "NoofLicences");
            dashboard.LstNoOfPrefferedContact = dashDetails.GetAllMiscToBind("Signup", "PrefferedContactMethod");
            dashboard.companyRegModel = dashDetails.getRegisteredUserDetails(selectedValue);

            return PartialView("_PartialCompany", dashboard);
        }

        #endregion



        #region Model Popup

        [HttpGet]
        public ActionResult ModelPopup()
        {
            return View();
        }
        [HttpPost]
        public ActionResult ModelPopup(FormCollection form)
        {
            return View();
        }

        #endregion

        #region UserProfile
        [HttpGet]
        public ActionResult UserProfile()
        {
            if (Session["modiicon"] != null)
            {
                iconPath = GetModiIconPath(Session["modiicon"].ToString());
            }
            dashboard = new DashBoard();
            DashBoard.modiIconPath = iconPath;
            return View();
        }
        [HttpGet]
        public ActionResult GetUserProfile(string searchValue)
        {
            dashboard = new DashBoard();
            dashDetails = new DashboardDetails();
            return View("UserProfile", dashboard);
        }

        [HttpGet]
        public JsonResult GetUser()
        {
            dashDetails = new DashboardDetails();
            UserSecrect secret = new UserSecrect();
            List<string> lst = dashDetails.getusrProfileSearch();
            return Json(lst, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public JsonResult GetUserdetailFromSearch(string searchId)
        {
            dashboard = new DashBoard();
            dashDetails = new DashboardDetails();
            dashboard.usrSearchProfileUpdate = dashDetails.searchUsert(searchId);
            return Json(dashboard.usrSearchProfileUpdate, JsonRequestBehavior.AllowGet);
        }

        public ActionResult UserProfilePost(DataAccess.DTOModels.UserProfileUpdate model)
        {
            dashboard = new DashBoard();
            dashDetails = new DashboardDetails();
            bool result = dashDetails.UserProfileUpdated(model);
            return Json(result);
        }
        [HttpPost]
        public ActionResult UserProfile(DataAccess.DTOModels.UserProfileUpdate model)
        {

            return RedirectToAction("UserProfile");
        }

        #endregion


        #region company profile
        [HttpGet]
        public ActionResult CompanyProfile()
        {
            if (Session["modiicon"] != null)
            {
                iconPath = GetModiIconPath(Session["modiicon"].ToString());
            }
            dashboard = new DashBoard();
            dashDetails = new DashboardDetails();
            DashBoard.modiIconPath = iconPath;
            dashboard.lstAllStateNames = dashDetails.GetAllStateNamesList();
            dashboard.LstNoOfEmpList = dashDetails.GetAllMiscToBind("Signup", "NoofEmployees");
            dashboard.LstNoOfLicencesList = dashDetails.GetAllMiscToBind("Signup", "NoofLicences");
            dashboard.LstNoOfRecStatusList = dashDetails.GetAllMiscToBind("Signup", "RecStatus");
            dashboard.LstNoOfPrefferedContact = dashDetails.GetAllMiscToBind("Signup", "PrefferedContactMethod");
            dashboard.companyRegModel = dashDetails.getRegisteredUserDetails(Session["ComapnyGuid"].ToString());

            return View("_PartialCompany", dashboard);
        }

        [HttpGet]
        public JsonResult GetCompany()
        {
            dashDetails = new DashboardDetails();
            UserSecrect secret = new UserSecrect();
            List<string> lst = dashDetails.getCompanyProfileSearch();
            return Json(lst, JsonRequestBehavior.AllowGet);
        }

        public ActionResult GetCompanySearchFromSearch(string companyname)
        {
            dashboard = new DashBoard();
            dashDetails = new DashboardDetails();

            dashboard.lstAllStateNames = dashDetails.GetAllStateNamesList();
            dashboard.LstNoOfEmpList = dashDetails.GetAllMiscToBind("Signup", "NoofEmployees");
            dashboard.LstNoOfLicencesList = dashDetails.GetAllMiscToBind("Signup", "NoofLicences");
            dashboard.LstNoOfPrefferedContact = dashDetails.GetAllMiscToBind("Signup", "PrefferedContactMethod");
            dashboard.companyRegModel = dashDetails.getCompanyProfileDetailOnSearch(companyname);
            return PartialView("_PartialCompanyProfile", dashboard);
        }

        #endregion

        [HttpGet]
        public ActionResult EmployeePerformance()
        {
            if (Session["modiicon"] != null)
            {
                iconPath = GetModiIconPath(Session["modiicon"].ToString());
            }
            dashboard = new DashBoard();
            DashBoard.modiIconPath = iconPath;
            dashDetails = new DashboardDetails();


            //dashboard.employeePerformanceMonthly = dashDetails.GetEmployeePerformanceMonthly("sonicgecadmin@sonic.com","","OCT" ,2015);
            empPerformObj = dashDetails.getEmployeeAllTabNames(Session["LoggedInUserEmail"].ToString(), "", "", "D");


            dashboard.metricList = empPerformObj.metricList;
            Session["KPIFirst"] = dashboard.metricList[0].KPIName;
            return View(dashboard);
        }

        [HttpGet]
        public ActionResult LoadEmployeePerScorecard(string selectedValue, string slidervalue, string Type)
        {
            dashboard = new DashBoard();
            dashDetails = new DashboardDetails();


            if (selectedValue == "" || selectedValue == null)
                selectedValue = Session["KPIFirst"].ToString();

            empPerformObj = dashDetails.getEmployeePerformance(Session["LoggedInUserEmail"].ToString(), selectedValue, slidervalue, Type);

            dashboard.metricList = empPerformObj.metricList;
            dashboard.employeeListCount = empPerformObj.employeeListCount;
            dashboard.employeePerformanceCardList = empPerformObj.employeePerformanceCardList;

            //if (dashboard.employeeListCount.Count == 1)
            //{
            //    return RedirectToAction("IndividualEmpPerf", "Dashboard");
            //}

            return PartialView("_PartialEmployeeScorecard", dashboard);
        }

        [HttpGet]
        public ActionResult IndividualEmpPerf(string email)
        {
            if (Session["modiicon"] != null)
            {
                iconPath = GetModiIconPath(Session["modiicon"].ToString());
            }
            dashboard = new DashBoard();
            DashBoard.modiIconPath = iconPath;
            dashDetails = new DashboardDetails();

            Session["email"] = email;

            //empIndPerfObj = dashDetails.getEmployeePerformanceIndividualDetails("James.Everitt@sonic.com", "OCT", 2015, "M");
            empIndPerfObj = dashDetails.getEmployeePerformanceIndividualDetails(email, "OCT", 2015, "M");

            dashboard.empIndGridList = empIndPerfObj.empIndGridList;
            dashboard.empIndOthrDetailsList = empIndPerfObj.empIndOthrDetailsList;
            dashboard.empIndPerfCard = empIndPerfObj.empIndPerfCard;

            if (dashboard.empIndPerfCard.Count != 0 || dashboard.empIndOthrDetailsList.Count != 0)
            {
                var IndividualPerfdetails = dashboard.empIndPerfCard.First();
                var IndividualPerfOtherdetails = dashboard.empIndOthrDetailsList.First();
                dashboard.IndividualPerfCardObjects = new EmployeePerformaceCard();
                dashboard.IndividualPerfCardObjectsOtherDetails = new IndividualPerformanceCardOtherDetails();

                foreach (var perfDetails in empIndPerfObj.empIndPerfCard)
                {
                    dashboard.IndividualPerfCardObjects.FirstName = perfDetails.FirstName;
                    dashboard.IndividualPerfCardObjects.LastName = perfDetails.LastName;
                    dashboard.IndividualPerfCardObjects.Title = perfDetails.Title;
                }

                foreach (var perfOtherDetails in empIndPerfObj.empIndOthrDetailsList)
                {
                    dashboard.IndividualPerfCardObjectsOtherDetails.companyname = perfOtherDetails.companyname;
                    dashboard.IndividualPerfCardObjectsOtherDetails.IntApt = perfOtherDetails.IntApt;
                    dashboard.IndividualPerfCardObjectsOtherDetails.PhoneApt = perfOtherDetails.PhoneApt;
                }
            }

            return View(dashboard);
        }

        [HttpGet]
        public ActionResult bindCoachingGridPerformance(string Type)
        {
            if (Session["modiicon"] != null)
            {
                iconPath = GetModiIconPath(Session["modiicon"].ToString());
            }

            dashboard = new DashBoard();
            DashBoard.modiIconPath = iconPath;
            dashDetails = new DashboardDetails();

            empIndPerfObj =
                dashDetails.GetIndividualPerformanceCardCoachingGridDetails(Session["ComapnyGuid"].ToString(), Session["email"].ToString());

            //empIndPerfObj =
            //    dashDetails.GetIndividualPerformanceCardCoachingGridDetails("496FFFB2-6E87-4769-94AA-D3807BAE2503", "James.Everitt@sonic.com");

            dashboard.empIndGridList = empIndPerfObj.empIndGridList;

            return PartialView("_PartialEmpPerfGrid", dashboard);

        }

        [HttpGet]
        public ActionResult bindTrainingGridPerformance(string Type)
        {
            if (Session["modiicon"] != null)
            {
                iconPath = GetModiIconPath(Session["modiicon"].ToString());
            }

            dashboard = new DashBoard();
            DashBoard.modiIconPath = iconPath;
            dashDetails = new DashboardDetails();

            //empIndPerfObj =
            //    dashDetails.GetIndividualPerformanceTrainingGridDetails(Session["ComapnyGuid"].ToString(), Session["email"].ToString());

            empIndPerfObj =
                dashDetails.GetIndividualPerformanceTrainingGridDetails("496FFFB2-6E87-4769-94AA-D3807BAE2503", "James.Everitt@sonic.com");

            // dashboard.empIndGridTrainingList = empIndPerfObj.empIndGridTrainingList;

            return PartialView("_PartialEmpPerfGrid", dashboard);

        }

        [HttpGet]
        public ActionResult bindEmpPerfCards(string Type)
        {
            if (Session["modiicon"] != null)
            {
                iconPath = GetModiIconPath(Session["modiicon"].ToString());
            }

            dashboard = new DashBoard();
            DashBoard.modiIconPath = iconPath;
            dashDetails = new DashboardDetails();

            //empIndPerfObj =
            //    dashDetails.GetIndividualPerformanceCardCoachingGridDetails(Session["ComapnyGuid"].ToString(), Session["email"].ToString());

            empIndPerfObj =
                dashDetails.GetIndividualPerformanceCardCoachingGridDetails("496FFFB2-6E87-4769-94AA-D3807BAE2503", "James.Everitt@sonic.com");

            dashboard.empIndGridList = empIndPerfObj.empIndGridList;

            return PartialView("_PartialEmpPerfGrid", dashboard);

        }



        [HttpGet]
        public ActionResult KnowledgeBase()
        {
            if (Session["modiicon"] != null)
            {
                iconPath = GetModiIconPath(Session["modiicon"].ToString());
            }
            dashboard = new DashBoard();
            DashBoard.modiIconPath = iconPath;

            return View();
        }

        #region KPI
        [HttpGet]
        public ActionResult KPI()
        {
            if (Session["modiicon"] != null)
            {
                iconPath = GetModiIconPath(Session["modiicon"].ToString());
            }
            dashboard = new DashBoard();
            dashDetails = new DashboardDetails();
            dashboard.CompanyModel = dashDetails.getCompanyInformation(Session["ComapnyGuid"].ToString());
            ViewBag.CompanyName = dashboard.CompanyModel.CompanyName;
            DashBoard.modiIconPath = iconPath;
            return View();
        }


        public JsonResult KPIInsert(Ampbi.DataAccess.DTOModels.KPIMetricModel model)
        {
            dashDetails = new DashboardDetails();
            model.companGUID = Session["ComapnyGuid"].ToString();
            bool result = dashDetails.insertKPI(model);
            return Json(true, JsonRequestBehavior.AllowGet);
        }

        #endregion

        #region QA Dashboard
        [HttpGet]
        public ActionResult QADashBoard_New()
        {
            if (Session["modiicon"] != null)
            {
                iconPath = GetModiIconPath(Session["modiicon"].ToString());
            }
            DashBoard.modiIconPath = iconPath;
            dashboard = new DashBoard();
            dashDetails = new DashboardDetails();
            //dashboard.getCompanyChartInfo = dashDetails.getCompanyChartInfo(2, Session["ComapnyGuid"].ToString());
            //dashboard.LstNoOfCallDashboardChartTypes = dashDetails.GetAllMiscToBind("CallDashboard", "ChartTypes");
            //dashboard.LstAgent = dashDetails.getAgentAndQuestion(Session["ComapnyGuid"].ToString(), "AGENT");
            //dashboard.LstQuestion = dashDetails.getAgentAndQuestion(Session["ComapnyGuid"].ToString(), "QAQUESTIONS");

            dashboard.parameters = dashDetails.getQADashboardParameter(Session["ComapnyGuid"].ToString(), "QA Dashboard", "Goal Vs Actual");
            return View(dashboard);
        }


        [HttpPost]
        public JsonResult bindcharDataQADashboard(string site, string program, string agent, string year, string month, string week, string type)
        {
            dashboard = new DashBoard();
            dashDetails = new DashboardDetails();
            //DateTime dt = DateTime.Parse(DateTime.Now.Date.ToShortDateString());
            //DateTime dt = DateTime.Parse(sliderValue);
            //dashboard.lstchartDetailQADashboard= dashDetails.getDataToBindChartforQADashBoard(Session["ComapnyGuid"].ToString(), 1, selectedAgentName, selectedQuestion, null, null, null, dt, type);

            //if (dashboard.lstchartDetailQADashboard.Count == 1)
            //{
            //    if (dashboard.lstchartDetailQADashboard[0].Value == 0)
            //    {
            //        dashboard.lstchartDetailQADashboard.Remove(dashboard.lstchartDetailQADashboard[0]);
            //    }
            //}

            program = AddSpacesToSentence(RemoveWhitespace(program), true);
            agent = AddSpacesToSentence(RemoveWhitespace(agent), true);
            year = AddSpacesToSentence(RemoveWhitespace(year), true);
            month = AddSpacesToSentence(RemoveWhitespace(month), true);
            week = AddSpacesToSentence(RemoveWhitespace(week == null ? string.Empty : week), true);
            //if (site == "AllSites")
            //    site = "All Sites";


            dashboard.getlstQADashboard = dashDetails.getDataToBindChartforQADashBoard(Session["ComapnyGuid"].ToString(), site, program, agent, year, month, week, type);
            return Json(dashboard.getlstQADashboard, JsonRequestBehavior.AllowGet);
        }



        [HttpGet]
        public ActionResult QADashBoard_New1()
        {
            if (Session["modiicon"] != null)
            {
                iconPath = GetModiIconPath(Session["modiicon"].ToString());
            }
            DashBoard.modiIconPath = iconPath;
            dashboard = new DashBoard();
            dashDetails = new DashboardDetails();
            ////dashboard.getCompanyChartInfo = dashDetails.getCompanyChartInfo(2, Session["ComapnyGuid"].ToString());
            ////dashboard.LstNoOfCallDashboardChartTypes = dashDetails.GetAllMiscToBind("CallDashboard", "ChartTypes");
            ////dashboard.LstAgent = dashDetails.getAgentAndQuestion(Session["ComapnyGuid"].ToString(), "AGENT");
            ////dashboard.LstQuestion = dashDetails.getAgentAndQuestion(Session["ComapnyGuid"].ToString(), "QAQUESTIONS");

            dashboard.parameters = dashDetails.getQADashboardParameter(Session["ComapnyGuid"].ToString(), "QA Dashboard", "Goal Vs Actual");
            return View(dashboard);
        }

        [HttpPost]
        public JsonResult QAScoreBindChartData(string site, string program, string agent, string year, string month, string week, string type)
        {
            dashboard = new DashBoard();
            dashDetails = new DashboardDetails();
            //program = AddSpacesToSentence(RemoveWhitespace(program), true);
            //agent = AddSpacesToSentence(RemoveWhitespace(agent), true);
            //year = AddSpacesToSentence(RemoveWhitespace(year), true);
            //month = AddSpacesToSentence(RemoveWhitespace(month), true);
            //week = AddSpacesToSentence(RemoveWhitespace(week == null ? string.Empty : week), true);
            program = AddSpacesToSentence(RemoveWhitespace(program), true);
            agent = AddSpacesToSentence(RemoveWhitespace(agent), true);
            year = AddSpacesToSentence(RemoveWhitespace(year), true);
            month = AddSpacesToSentence(RemoveWhitespace(month), true);
            week = AddSpacesToSentence(RemoveWhitespace(week == null ? string.Empty : week), true);
            dashboard.qascore1 = dashDetails.QAScoreChart1(Session["ComapnyGuid"].ToString(), site, program, agent, year, month, week, type);
            // dashboard.lstchartDetails = dashDetails.getDataToBindChart(Session["LoggedInUserEmail"].ToString(), Session["ComapnyGuid"].ToString(), 1, selectedDealerVal, selectedMarketVal, string.Empty, string.Empty, string.Empty, dt, type);
            return Json(dashboard.qascore1, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public JsonResult QAScoreBindChartDatadispositionlvl1(string site, string program, string agent, string year, string month, string week, string type, string selectedChartDispVal1)
        {
            dashboard = new DashBoard();
            dashDetails = new DashboardDetails();
            //DateTime dt = DateTime.Parse(sliderValue1);
            Session["QAScoredispositionLevel1"] = selectedChartDispVal1;
            program = AddSpacesToSentence(RemoveWhitespace(program), true);
            agent = AddSpacesToSentence(RemoveWhitespace(agent), true);
            year = AddSpacesToSentence(RemoveWhitespace(year), true);
            month = AddSpacesToSentence(RemoveWhitespace(month), true);
            week = AddSpacesToSentence(RemoveWhitespace(week == null ? string.Empty : week), true);


            dashboard.qascore2 = dashDetails.QAScoreChart2(Session["ComapnyGuid"].ToString(), site, program, agent, year, month, week, type, selectedChartDispVal1);

            //dashboard.lstchartDetails = dashDetails.getDataToBindChart(Session["LoggedInUserEmail"].ToString(), Session["ComapnyGuid"].ToString(), 2, selectedDealerVal, selectedMarketVal, selectedChartDispVal1, string.Empty, string.Empty, dt, leveltype);

            return Json(dashboard.qascore2, JsonRequestBehavior.AllowGet);
        }



        [HttpPost]
        public JsonResult QAScoreBindChartDatadispositionlvl2(string site, string program, string agent, string year, string month, string week, string type, string selectedChartDispVal1)
        {
            dashboard = new DashBoard();
            dashDetails = new DashboardDetails();
            //DateTime dt = DateTime.Parse(sliderValue1);
            Session["QAScoredispositionLevel2"] = selectedChartDispVal1;
            program = AddSpacesToSentence(RemoveWhitespace(program), true);
            agent = AddSpacesToSentence(RemoveWhitespace(agent), true);
            year = AddSpacesToSentence(RemoveWhitespace(year), true);
            month = AddSpacesToSentence(RemoveWhitespace(month), true);
            week = AddSpacesToSentence(RemoveWhitespace(week == null ? string.Empty : week), true);


            dashboard.qascore3 = dashDetails.QAScoreChart3(Session["ComapnyGuid"].ToString(), site, Session["QAScoredispositionLevel1"].ToString(), agent, year, month, week, type, Session["QAScoredispositionLevel1"].ToString(), selectedChartDispVal1);

            //dashboard.lstchartDetails = dashDetails.getDataToBindChart(Session["LoggedInUserEmail"].ToString(), Session["ComapnyGuid"].ToString(), 2, selectedDealerVal, selectedMarketVal, selectedChartDispVal1, string.Empty, string.Empty, dt, leveltype);

            return Json(dashboard.qascore3, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public JsonResult QAScoreBindChartDatadispositionlvl3(string site, string program, string agent, string year, string month, string week, string type, string selectedChartDispVal1)
        {
            dashboard = new DashBoard();
            dashDetails = new DashboardDetails();
            //DateTime dt = DateTime.Parse(sliderValue1);

            program = AddSpacesToSentence(RemoveWhitespace(program), true);
            agent = AddSpacesToSentence(RemoveWhitespace(agent), true);
            year = AddSpacesToSentence(RemoveWhitespace(year), true);
            month = AddSpacesToSentence(RemoveWhitespace(month), true);
            week = AddSpacesToSentence(RemoveWhitespace(week == null ? string.Empty : week), true);


            dashboard.qascore4 = dashDetails.QAScoreChart4(Session["ComapnyGuid"].ToString(), site, program, agent, year, month, week, type, Session["QAScoredispositionLevel1"].ToString(), Session["QAScoredispositionLevel2"].ToString(), selectedChartDispVal1);

            //dashboard.lstchartDetails = dashDetails.getDataToBindChart(Session["LoggedInUserEmail"].ToString(), Session["ComapnyGuid"].ToString(), 2, selectedDealerVal, selectedMarketVal, selectedChartDispVal1, string.Empty, string.Empty, dt, leveltype);

            return Json(dashboard.qascore4, JsonRequestBehavior.AllowGet);
        }






        [HttpGet]
        public ActionResult QADashBoard_New2()
        {
            if (Session["modiicon"] != null)
            {
                iconPath = GetModiIconPath(Session["modiicon"].ToString());
            }
            DashBoard.modiIconPath = iconPath;
            dashboard = new DashBoard();
            dashDetails = new DashboardDetails();
            ////dashboard.getCompanyChartInfo = dashDetails.getCompanyChartInfo(2, Session["ComapnyGuid"].ToString());
            ////dashboard.LstNoOfCallDashboardChartTypes = dashDetails.GetAllMiscToBind("CallDashboard", "ChartTypes");
            ////dashboard.LstAgent = dashDetails.getAgentAndQuestion(Session["ComapnyGuid"].ToString(), "AGENT");
            ////dashboard.LstQuestion = dashDetails.getAgentAndQuestion(Session["ComapnyGuid"].ToString(), "QAQUESTIONS");


            dashboard.parameters = dashDetails.getQADashboardParameter(Session["ComapnyGuid"].ToString(), "QA Dashboard", "Goal Vs Actual");
            return View(dashboard);
        }

        [HttpPost]
        public JsonResult QABehavioronBindChartData(string site, string program, string agent, string year, string month, string week, string type)
        {
            dashboard = new DashBoard();
            dashDetails = new DashboardDetails();
            //program = AddSpacesToSentence(RemoveWhitespace(program), true);
            //agent = AddSpacesToSentence(RemoveWhitespace(agent), true);
            //year = AddSpacesToSentence(RemoveWhitespace(year), true);
            //month = AddSpacesToSentence(RemoveWhitespace(month), true);
            //week = AddSpacesToSentence(RemoveWhitespace(week == null ? string.Empty : week), true);
            program = AddSpacesToSentence(RemoveWhitespace(program), true);
            agent = AddSpacesToSentence(RemoveWhitespace(agent), true);
            year = AddSpacesToSentence(RemoveWhitespace(year), true);
            month = AddSpacesToSentence(RemoveWhitespace(month), true);
            week = AddSpacesToSentence(RemoveWhitespace(week == null ? string.Empty : week), true);
            dashboard.qabehaviroal1 = dashDetails.QABehavioralChart1(Session["ComapnyGuid"].ToString(), site, program, agent, year, month, week, type);
            // dashboard.lstchartDetails = dashDetails.getDataToBindChart(Session["LoggedInUserEmail"].ToString(), Session["ComapnyGuid"].ToString(), 1, selectedDealerVal, selectedMarketVal, string.Empty, string.Empty, string.Empty, dt, type);
            return Json(dashboard.qabehaviroal1, JsonRequestBehavior.AllowGet);
        }


        [HttpPost]
        public JsonResult QABehavioronBindChartDatadispositionlvl1(string site, string program, string agent, string year, string month, string week, string type, string selectedChartDispVal1)
        {
            dashboard = new DashBoard();
            dashDetails = new DashboardDetails();
            //DateTime dt = DateTime.Parse(sliderValue1);
            Session["QAdispositionLevel1"] = selectedChartDispVal1;
            program = AddSpacesToSentence(RemoveWhitespace(program), true);
            agent = AddSpacesToSentence(RemoveWhitespace(agent), true);
            year = AddSpacesToSentence(RemoveWhitespace(year), true);
            month = AddSpacesToSentence(RemoveWhitespace(month), true);
            week = AddSpacesToSentence(RemoveWhitespace(week == null ? string.Empty : week), true);


            dashboard.qabehaviroal2 = dashDetails.QABehavioralChart2(Session["ComapnyGuid"].ToString(), site, program, agent, year, month, week, type, selectedChartDispVal1);

            //dashboard.lstchartDetails = dashDetails.getDataToBindChart(Session["LoggedInUserEmail"].ToString(), Session["ComapnyGuid"].ToString(), 2, selectedDealerVal, selectedMarketVal, selectedChartDispVal1, string.Empty, string.Empty, dt, leveltype);

            return Json(dashboard.qabehaviroal2, JsonRequestBehavior.AllowGet);
        }


        [HttpPost]
        public JsonResult QABehavioronBindChartDatadispositionlvl2(string site, string program, string agent, string year, string month, string week, string type, string selectedChartDispVal2)
        {
            dashboard = new DashBoard();
            dashDetails = new DashboardDetails();
            //DateTime dt = DateTime.Parse(sliderValue);

            Session["QAdispositionLevel2"] = selectedChartDispVal2;
            //dashboard.lstchartDetails = dashDetails.getDataToBindChart(Session["LoggedInUserEmail"].ToString(), Session["ComapnyGuid"].ToString(), 3, selectedDealerVal, selectedMarketVal, Session["QAdispositionLevel1"].ToString(), selectedChartDispVal2, string.Empty, dt, secondlevel);
            program = AddSpacesToSentence(RemoveWhitespace(program), true);
            agent = AddSpacesToSentence(RemoveWhitespace(agent), true);
            year = AddSpacesToSentence(RemoveWhitespace(year), true);
            month = AddSpacesToSentence(RemoveWhitespace(month), true);
            week = AddSpacesToSentence(RemoveWhitespace(week == null ? string.Empty : week), true);
            dashboard.qabehaviroal3 = dashDetails.QABehavioralChart3(Session["ComapnyGuid"].ToString(), site, program, agent, year, month, week, type, Session["QAdispositionLevel1"].ToString(), selectedChartDispVal2);
            return Json(dashboard.qabehaviroal3, JsonRequestBehavior.AllowGet);
        }
        [HttpPost]
        public JsonResult QABehavioronBindChartDatadispositionlvl3(string site, string program, string agent, string year, string month, string week, string type, string selectedChartDispVal3)
        {
            dashboard = new DashBoard();
            dashDetails = new DashboardDetails();
            //DateTime dt = DateTime.Parse(sliderValue);
            program = AddSpacesToSentence(RemoveWhitespace(program), true);
            agent = AddSpacesToSentence(RemoveWhitespace(agent), true);
            year = AddSpacesToSentence(RemoveWhitespace(year), true);
            month = AddSpacesToSentence(RemoveWhitespace(month), true);
            week = AddSpacesToSentence(RemoveWhitespace(week == null ? string.Empty : week), true);
            dashboard.qabehaviroal4 = dashDetails.QABehavioralChart4(Session["ComapnyGuid"].ToString(), site, program, agent, year, month, week, type, Session["QAdispositionLevel1"].ToString(), Session["QAdispositionLevel2"].ToString(), selectedChartDispVal3);
            return Json(dashboard.qabehaviroal4, JsonRequestBehavior.AllowGet);
        }



        #endregion


        #region Performance Dashboard


        [HttpGet]
        public ActionResult Utilization()
        {
            if (Session["modiicon"] != null)
            {
                iconPath = GetModiIconPath(Session["modiicon"].ToString());
            }
            DashBoard.modiIconPath = iconPath;
            dashboard = new DashBoard();
            dashDetails = new DashboardDetails();
            ////dashboard.getCompanyChartInfo = dashDetails.getCompanyChartInfo(2, Session["ComapnyGuid"].ToString());
            ////dashboard.LstNoOfCallDashboardChartTypes = dashDetails.GetAllMiscToBind("CallDashboard", "ChartTypes");
            ////dashboard.LstAgent = dashDetails.getAgentAndQuestion(Session["ComapnyGuid"].ToString(), "AGENT");
            ////dashboard.LstQuestion = dashDetails.getAgentAndQuestion(Session["ComapnyGuid"].ToString(), "QAQUESTIONS");


            dashboard.parameters = dashDetails.getQADashboardParameter(Session["ComapnyGuid"].ToString(), "QA Dashboard", "Goal Vs Actual");
            return View(dashboard);
        }

        [HttpPost]
        public JsonResult UtilizationBindChartData(string site, string program, string agent, string year, string month, string week, string type)
        {
            dashboard = new DashBoard();
            dashDetails = new DashboardDetails();
            //program = AddSpacesToSentence(RemoveWhitespace(program), true);
            //agent = AddSpacesToSentence(RemoveWhitespace(agent), true);
            //year = AddSpacesToSentence(RemoveWhitespace(year), true);
            //month = AddSpacesToSentence(RemoveWhitespace(month), true);
            //week = AddSpacesToSentence(RemoveWhitespace(week == null ? string.Empty : week), true);
            program = AddSpacesToSentence(RemoveWhitespace(program), true);
            agent = AddSpacesToSentence(RemoveWhitespace(agent), true);
            year = AddSpacesToSentence(RemoveWhitespace(year), true);
            month = AddSpacesToSentence(RemoveWhitespace(month), true);
            week = AddSpacesToSentence(RemoveWhitespace(week == null ? string.Empty : week), true);
            dashboard.Utilization1 = dashDetails.UtilizationChart1(Session["ComapnyGuid"].ToString(),"", site, program, agent, year, month, week, type);
            // dashboard.lstchartDetails = dashDetails.getDataToBindChart(Session["LoggedInUserEmail"].ToString(), Session["ComapnyGuid"].ToString(), 1, selectedDealerVal, selectedMarketVal, string.Empty, string.Empty, string.Empty, dt, type);
            return Json(dashboard.Utilization1, JsonRequestBehavior.AllowGet);
        }


        [HttpPost]
        public JsonResult UtilizationBindChartDatadispositionlvl1(string site, string program, string agent, string year, string month, string week, string type, string selectedChartDispVal1)
        {
            dashboard = new DashBoard();
            dashDetails = new DashboardDetails();
            //DateTime dt = DateTime.Parse(sliderValue1);
            Session["UtilizationdispositionLevel1"] = selectedChartDispVal1;
            program = AddSpacesToSentence(RemoveWhitespace(program), true);
            agent = AddSpacesToSentence(RemoveWhitespace(agent), true);
            year = AddSpacesToSentence(RemoveWhitespace(year), true);
            month = AddSpacesToSentence(RemoveWhitespace(month), true);
            week = AddSpacesToSentence(RemoveWhitespace(week == null ? string.Empty : week), true);


            dashboard.Utilization2 = dashDetails.UtilizationChart2(Session["ComapnyGuid"].ToString(), "", site, program, agent, year, month, week, type, selectedChartDispVal1);

            //dashboard.lstchartDetails = dashDetails.getDataToBindChart(Session["LoggedInUserEmail"].ToString(), Session["ComapnyGuid"].ToString(), 2, selectedDealerVal, selectedMarketVal, selectedChartDispVal1, string.Empty, string.Empty, dt, leveltype);

            return Json(dashboard.Utilization2, JsonRequestBehavior.AllowGet);
        }


        [HttpPost]
        public JsonResult UtilizationBindChartDatadispositionlvl2(string site, string program, string agent, string year, string month, string week, string type, string selectedChartDispVal2)
        {
            dashboard = new DashBoard();
            dashDetails = new DashboardDetails();
            //DateTime dt = DateTime.Parse(sliderValue);

            Session["UtilizationdispositionLevel2"] = selectedChartDispVal2;
            //dashboard.lstchartDetails = dashDetails.getDataToBindChart(Session["LoggedInUserEmail"].ToString(), Session["ComapnyGuid"].ToString(), 3, selectedDealerVal, selectedMarketVal, Session["QAdispositionLevel1"].ToString(), selectedChartDispVal2, string.Empty, dt, secondlevel);
            program = AddSpacesToSentence(RemoveWhitespace(program), true);
            agent = AddSpacesToSentence(RemoveWhitespace(agent), true);
            year = AddSpacesToSentence(RemoveWhitespace(year), true);
            month = AddSpacesToSentence(RemoveWhitespace(month), true);
            week = AddSpacesToSentence(RemoveWhitespace(week == null ? string.Empty : week), true);
            dashboard.Utilization3 = dashDetails.UtilizationChart3(Session["ComapnyGuid"].ToString(),"", site, program, agent, year, month, week, type, Session["UtilizationdispositionLevel1"].ToString(), selectedChartDispVal2);
            return Json(dashboard.Utilization3, JsonRequestBehavior.AllowGet);
        }
        [HttpPost]
        public JsonResult UtilizationtDatadispositionlvl3(string site, string program, string agent, string year, string month, string week, string type, string selectedChartDispVal3)
        {
            dashboard = new DashBoard();
            dashDetails = new DashboardDetails();
            //DateTime dt = DateTime.Parse(sliderValue);
            program = AddSpacesToSentence(RemoveWhitespace(program), true);
            agent = AddSpacesToSentence(RemoveWhitespace(agent), true);
            year = AddSpacesToSentence(RemoveWhitespace(year), true);
            month = AddSpacesToSentence(RemoveWhitespace(month), true);
            week = AddSpacesToSentence(RemoveWhitespace(week == null ? string.Empty : week), true);
            dashboard.Utilization4 = dashDetails.UtilizationChart4(Session["ComapnyGuid"].ToString(), "", site, program, agent, year, month, week, type, Session["UtilizationdispositionLevel1"].ToString(), Session["UtilizationdispositionLevel2"].ToString(), selectedChartDispVal3);
            return Json(dashboard.Utilization4, JsonRequestBehavior.AllowGet);
        }

        #endregion

        #region Appointment Dashboard
        [HttpGet]
        public ActionResult ApptDashBoard()
        {
            if (Session["modiicon"] != null)
            {
                iconPath = GetModiIconPath(Session["modiicon"].ToString());
            }
            dashboard = new DashBoard();
            DashBoard.modiIconPath = iconPath;
            return View();
        }

        #endregion

        #region Call Dashboard
        [HttpGet]
        public ActionResult CallDashBoard()
        {
            if (Session["modiicon"] != null)
            {
                iconPath = GetModiIconPath(Session["modiicon"].ToString());
            }

            dashboard = new DashBoard();
            dashDetails = new DashboardDetails();
            dashboard.LstDelears = dashDetails.getDealersAndMarkets(Session["ComapnyGuid"].ToString(), "Dealer", null);
            dashboard.LstMarkets = dashDetails.getDealersAndMarkets(Session["ComapnyGuid"].ToString(), "Market", null);
            dashboard.getCompanyChartInfo = dashDetails.getCompanyChartInfo(2, Session["ComapnyGuid"].ToString());
            dashboard.LstNoOfCallDashboardChartTypes = dashDetails.GetAllMiscToBind("CallDashboard", "ChartTypes");
            DashBoard.modiIconPath = iconPath;
            if (Convert.ToInt32(Session["UserType"]) == 1)
            {
                return View("CallDashBoard", dashboard);
            }

            return View("ChimesAgentCallDashBoard", dashboard);
        }


        [HttpPost]
        public ActionResult CallDashBoard(string id)
        {
            DashBoard.mainMenuItem = "CallDash";
            return View();
        }


        [HttpPost]
        public JsonResult GetMonthlyData(string sliderValue, string Type)
        {
            dashboard = new DashBoard();
            dashDetails = new DashboardDetails();
            var silderdate = Convert.ToDateTime(sliderValue);
            dashboard.totalCallsCount = dashDetails.getCallsCount(Type, Session["ComapnyGuid"].ToString(), Convert.ToInt32(silderdate.Date.Day), Convert.ToInt32(silderdate.Month), Convert.ToInt32(silderdate.Year));
            DateTime dt = DateTime.Parse(sliderValue);
            //Session["dispositionLevel1"] = selectedChartDispVal1;
            // dashboard.lstchartDetails = dashDetails.getDataToBindChart(Session["ComapnyGuid"].ToString(), 1, null, null,0, 0, 0, dt);
            return Json(dashboard, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public JsonResult bindMarketData(string selectedDealerVal, string sliderValue, string Type)
        {
            dashboard = new DashBoard();
            dashDetails = new DashboardDetails();
            dashboard.LstMarkets = dashDetails.getDealersAndMarkets(Session["ComapnyGuid"].ToString(), "Market", selectedDealerVal);
            //if (sliderValue == null)
            //{
            //    return null;
            //}
            ////dashboard.LstDelears = dashDetails.getDealersAndMarkets(Session["ComapnyGuid"].ToString(), "Dealer", null);
            //DateTime dt = DateTime.Parse(sliderValue);
            ////Session["dispositionLevel1"] = selectedChartDispVal1;
            //dashboard.lstchartDetails = dashDetails.getDataToBindChart(Session["LoggedInUserEmail"].ToString(),Session["ComapnyGuid"].ToString(), 1, selectedDealerVal, null, string.Empty, string.Empty, string.Empty, dt, Type);

            return Json(dashboard, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public JsonResult bindcharData(string selectedMarketVal, string selectedDealerVal, string sliderValue, string type)
        {
            dashboard = new DashBoard();
            dashDetails = new DashboardDetails();
            //DateTime dt = DateTime.Parse(DateTime.Now.Date.ToShortDateString());
            DateTime dt = DateTime.Parse(sliderValue);
            dashboard.lstchartDetails = dashDetails.getDataToBindChart(Session["LoggedInUserEmail"].ToString(), Session["ComapnyGuid"].ToString(), 1, selectedDealerVal, selectedMarketVal, string.Empty, string.Empty, string.Empty, dt, type);
            return Json(dashboard.lstchartDetails, JsonRequestBehavior.AllowGet);
        }


        [HttpPost]
        public JsonResult bindcharDatadispositionlvl1(string selectedChartDispVal1, string selectedMarketVal, string selectedDealerVal, string sliderValue1, string leveltype)
        {
            dashboard = new DashBoard();
            dashDetails = new DashboardDetails();
            DateTime dt = DateTime.Parse(sliderValue1);
            Session["dispositionLevel1"] = selectedChartDispVal1;
            dashboard.lstchartDetails = dashDetails.getDataToBindChart(Session["LoggedInUserEmail"].ToString(), Session["ComapnyGuid"].ToString(), 2, selectedDealerVal, selectedMarketVal, selectedChartDispVal1, string.Empty, string.Empty, dt, leveltype);

            return Json(dashboard.lstchartDetails, JsonRequestBehavior.AllowGet);
        }


        [HttpPost]
        public JsonResult bindcharDatadispositionlvl2(string selectedChartDispVal2, string selectedMarketVal, string selectedDealerVal, string sliderValue, string secondlevel)
        {
            dashboard = new DashBoard();
            dashDetails = new DashboardDetails();
            DateTime dt = DateTime.Parse(sliderValue);

            Session["dispositionLevel2"] = selectedChartDispVal2;
            dashboard.lstchartDetails = dashDetails.getDataToBindChart(Session["LoggedInUserEmail"].ToString(), Session["ComapnyGuid"].ToString(), 3, selectedDealerVal, selectedMarketVal, Session["dispositionLevel1"].ToString(), selectedChartDispVal2, string.Empty, dt, secondlevel);
            return Json(dashboard.lstchartDetails, JsonRequestBehavior.AllowGet);
        }
        [HttpPost]
        public JsonResult bindcharDatadispositionlvl3(string selectedChartDispVal3, string selectedMarketVal, string selectedDealerVal, string sliderValue, string Thirdlevel)
        {
            dashboard = new DashBoard();
            dashDetails = new DashboardDetails();
            DateTime dt = DateTime.Parse(sliderValue);

            dashboard.lstchartDetails = dashDetails.getDataToBindChart(Session["LoggedInUserEmail"].ToString(), Session["ComapnyGuid"].ToString(), 4, selectedDealerVal, selectedMarketVal, Session["dispositionLevel1"].ToString(), Session["dispositionLevel2"].ToString(), selectedChartDispVal3, dt, Thirdlevel);

            return Json(dashboard.lstchartDetails, JsonRequestBehavior.AllowGet);
        }



        #endregion


        #region VirtualAssistant
        public ActionResult VirtualAssistant()
        {
            if (Session["modiicon"] != null)
            {
                iconPath = GetModiIconPath(Session["modiicon"].ToString());
            }

            dashboard = new DashBoard();
            DashBoard.modiIconPath = iconPath;
            dashDetails = new DashboardDetails();
            return View();
        }
        #endregion

        #region


        [HttpGet]
        public ActionResult LogOut()
        {
            Session.Clear();
            Session.Abandon();
            Session.RemoveAll();
          
            FormsAuthentication.SignOut();
            return RedirectToAction("Login", "Account");
        }

        #endregion

        #region private
        private string GetModiIconPath(string id)
        {
            string path = string.Empty;
            if (!string.IsNullOrEmpty(id))
            {
                if (id == "1")
                    path = "active-green";
                else if (id == "2")
                    path = "active-yellow";
                else if (id == "3")
                    path = "active-red";
                //path = @"~/Content/assets/images/smile" + id + ".png";
            }
            return path;
        }
        public string RemoveWhitespace(string input)
        {
            return new string(input.ToCharArray()
                .Where(c => !Char.IsWhiteSpace(c))
                .ToArray());
        }

        string AddSpacesToSentence(string text, bool preserveAcronyms)
        {
            if (string.IsNullOrWhiteSpace(text))
                return string.Empty;
            StringBuilder newText = new StringBuilder(text.Length * 2);
            newText.Append(text[0]);
            for (int i = 1; i < text.Length; i++)
            {
                if (char.IsUpper(text[i]))
                    if ((text[i - 1] != ' ' && !char.IsUpper(text[i - 1])) ||
                        (preserveAcronyms && char.IsUpper(text[i - 1]) &&
                         i < text.Length - 1 && !char.IsUpper(text[i + 1])))
                        newText.Append(' ');
                newText.Append(text[i]);
            }
            return newText.ToString();
        }


        [HttpPost]
        public JsonResult InsertLog(AppLogModel model)
        {
            dashDetails = new DashboardDetails();
            //    DateTime dt = DateTime.Parse(Sliderval);
            model.CompanyGUID = Session["ComapnyGuid"].ToString();
            model.UserEmailID = Session["LoggedInUserEmail"].ToString();
            bool result = dashDetails.InsertLog(model);

            return Json(true, JsonRequestBehavior.AllowGet);
        }


        #endregion
    }
}
